package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Registration extends HttpServlet {
	 protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		 String name = req.getParameter("name");
		 String password = req.getParameter("password");
		 String email = req.getParameter("email");
		 
		 res.setContentType("text/html ");
		 PrintWriter out = res.getWriter();
		 if(name != null && password != null && email != null) {
			 out.print("success");
		 }
		 
		 
	 }
}
